package com.pupku.detoxtracker;

import javax.swing.*;
import java.awt.*;
import com.pupku.detoxtracker.view.TimerPanel;
import com.pupku.detoxtracker.view.ChallengePanel;
import com.pupku.detoxtracker.view.FocusModePanel;
import com.pupku.detoxtracker.view.RewardPanel;

/**
 * Main application window for Social Media Detox Tracker.
 */
public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel contentPanel;

    public MainFrame() {
        super("Social Media Detox Tracker");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        // Top navigation buttons
        JPanel menuPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 20));
        JButton timerButton     = new JButton("Timer");
        JButton challengeButton = new JButton("Challenge");
        JButton focusButton     = new JButton("Focus Mode");
        JButton rewardsButton   = new JButton("Rewards");
        menuPanel.add(timerButton);
        menuPanel.add(challengeButton);
        menuPanel.add(focusButton);
        menuPanel.add(rewardsButton);
        add(menuPanel, BorderLayout.NORTH);

        // Content area with CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.add(new JLabel("Welcome to Social Media Detox Tracker", SwingConstants.CENTER), "home");
        contentPanel.add(new TimerPanel(),     "timer");
        contentPanel.add(new ChallengePanel(), "challenge");
        contentPanel.add(new FocusModePanel(), "focus");
        contentPanel.add(new RewardPanel(),    "rewards");
        add(contentPanel, BorderLayout.CENTER);

        // Button event handlers
        timerButton.addActionListener(e -> cardLayout.show(contentPanel, "timer"));
        challengeButton.addActionListener(e -> cardLayout.show(contentPanel, "challenge"));
        focusButton.addActionListener(e -> cardLayout.show(contentPanel, "focus"));
        rewardsButton.addActionListener(e -> cardLayout.show(contentPanel, "rewards"));
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}