package com.pupku.detoxtracker;

import com.pupku.detoxtracker.service.*;

public class AppController {
    private static AppController instance;
    public final TimerManager timerManager;
    public final ChallengeManager challengeManager;
    private final PersistenceHelper persistence;

    private AppController() {
        persistence      = new PersistenceHelper("detox-data.json");
        TimerData td     = persistence.load(TimerData.class);
        ChallengeData cd = persistence.load(ChallengeData.class);

        timerManager     = new TimerManager(td.getTotalSeconds());
        challengeManager = new ChallengeManager(cd.getCompleted());
    }

    public static AppController getInstance() {
        if (instance == null) instance = new AppController();
        return instance;
    }

    public void saveAll() {
        persistence.save(new TimerData(timerManager.getTotalDuration().getSeconds()));
        persistence.save(new ChallengeData(challengeManager.getChallengeHistory()));
    }
}
