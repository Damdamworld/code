package com.pupku.detoxtracker.view;

import javax.swing.*;
import java.awt.*;
import com.pupku.detoxtracker.AppController;

/**
 * Panel for presenting daily reduction challenges with persistence.
 */
public class ChallengePanel extends JPanel {
    private final JLabel titleLabel;
    private final JLabel statusLabel;
    private final JLabel challengeLabel;
    private final JButton nextButton;
    private final String[] challenges = {
        "Reduce social media use by 10 minutes today",
        "Limit usage to 1 hour only",
        "Take a 15-minute break every hour",
        "No social media after 8 PM",
        "Use social media only for messaging"
    };
    private int currentIndex = 0;

    public ChallengePanel() {
        setLayout(new BorderLayout(10, 10));

        // North: title + completed count
        titleLabel = new JLabel("Daily Reduction Challenge", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        int completedCount = AppController.getInstance()
                                         .challengeManager
                                         .getChallengeHistory()
                                         .size();
        statusLabel = new JLabel("Completed: " + completedCount, SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.add(titleLabel, BorderLayout.NORTH);
        northPanel.add(statusLabel, BorderLayout.SOUTH);
        add(northPanel, BorderLayout.NORTH);

        // Center: current challenge
        challengeLabel = new JLabel(challenges[currentIndex], SwingConstants.CENTER);
        challengeLabel.setFont(new Font("Monospaced", Font.PLAIN, 18));
        add(challengeLabel, BorderLayout.CENTER);

        // South: button
        nextButton = new JButton("Complete & Next");
        nextButton.addActionListener(e -> handleNext());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(nextButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void handleNext() {
        // 1) record and save
        String done = challenges[currentIndex];
        AppController.getInstance().challengeManager.completeChallenge(done);
        AppController.getInstance().saveAll();

        // 2) update status label
        int count = AppController.getInstance()
                                .challengeManager
                                .getChallengeHistory()
                                .size();
        statusLabel.setText("Completed: " + count);

        // 3) advance to next
        currentIndex = (currentIndex + 1) % challenges.length;
        challengeLabel.setText(challenges[currentIndex]);
    }
}
