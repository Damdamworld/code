package com.pupku.detoxtracker.view;

import javax.swing.*;
import java.awt.*;
import java.time.Duration;
import java.time.Instant;
import com.pupku.detoxtracker.AppController;

/**
 * Panel for tracking daily social media usage time,
 * with both session timer and cumulative total.
 */
public class TimerPanel extends JPanel {
    private JLabel totalUsageLabel;
    private JLabel sessionTimeLabel;
    private JButton startButton;
    private JButton stopButton;
    private Timer updateTimer;
    private Instant sessionStart;

    public TimerPanel() {
        setLayout(new BorderLayout(10, 10));

        // 1) Load cumulative total from controller
        Duration total = AppController.getInstance().timerManager.getTotalDuration();
        totalUsageLabel = new JLabel("Total Usage: " + formatDuration(total),
                                     SwingConstants.CENTER);
        totalUsageLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));
        add(totalUsageLabel, BorderLayout.NORTH);

        // 2) Session timer display
        sessionTimeLabel = new JLabel("00:00:00", SwingConstants.CENTER);
        sessionTimeLabel.setFont(new Font("Monospaced", Font.BOLD, 32));
        add(sessionTimeLabel, BorderLayout.CENTER);

        // 3) Control buttons
        startButton = new JButton("Start");
        stopButton  = new JButton("Stop");
        stopButton.setEnabled(false);
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        btnPanel.add(startButton);
        btnPanel.add(stopButton);
        add(btnPanel, BorderLayout.SOUTH);

        // 4) Timer to update session display
        updateTimer = new Timer(1000, e -> {
            Duration elapsed = Duration.between(sessionStart, Instant.now());
            sessionTimeLabel.setText(formatDuration(elapsed));
        });

        // 5) Start button logic
        startButton.addActionListener(e -> {
            AppController.getInstance().timerManager.startSession();
            sessionStart = Instant.now();
            updateTimer.start();
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
        });

        // 6) Stop button logic
        stopButton.addActionListener(e -> {
            updateTimer.stop();
            AppController.getInstance().timerManager.stopSession();
            AppController.getInstance().saveAll();

            // update both displays
            Duration newTotal = AppController.getInstance()
                                            .timerManager
                                            .getTotalDuration();
            totalUsageLabel.setText("Total Usage: " + formatDuration(newTotal));
            sessionTimeLabel.setText("00:00:00");

            startButton.setEnabled(true);
            stopButton.setEnabled(false);
        });
    }

    /** Utility to format a Duration as HH:mm:ss */
    private String formatDuration(Duration d) {
        long hours   = d.toHours();
        int minutes = d.toMinutesPart();
        int seconds = d.toSecondsPart();
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}
