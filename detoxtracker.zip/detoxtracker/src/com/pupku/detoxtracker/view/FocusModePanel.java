package com.pupku.detoxtracker.view;

import javax.swing.*;
import java.awt.*;

/**
 * Panel for activating focus mode to block social media temporarily.
 */
public class FocusModePanel extends JPanel {
    private JButton startFocusButton;
    private JButton stopFocusButton;
    private JPanel overlayPanel;
    private Timer focusTimer;
    private int remainingSeconds;

    public FocusModePanel() {
        setLayout(new BorderLayout(10, 10));
        JLabel title = new JLabel("Focus Mode: Block Social Media", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        startFocusButton = new JButton("Start Focus (5 min)");
        stopFocusButton  = new JButton("Stop Focus");
        stopFocusButton.setEnabled(false);
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        controlPanel.add(startFocusButton);
        controlPanel.add(stopFocusButton);
        add(controlPanel, BorderLayout.SOUTH);

        overlayPanel = new JPanel(new BorderLayout());
        overlayPanel.setOpaque(true);
        overlayPanel.setBackground(new Color(0, 0, 0, 150));
        JLabel overlayLabel = new JLabel("Focus Mode Active", SwingConstants.CENTER);
        overlayLabel.setFont(new Font("SansSerif", Font.BOLD, 28));
        overlayLabel.setForeground(Color.WHITE);
        overlayPanel.add(overlayLabel, BorderLayout.CENTER);
        overlayPanel.setVisible(false);
        add(overlayPanel, BorderLayout.CENTER);

        remainingSeconds = 5 * 60;
        focusTimer = new Timer(1000, e -> {
            remainingSeconds--;
            if (remainingSeconds <= 0) endFocusMode();
        });

        startFocusButton.addActionListener(e -> startFocusMode());
        stopFocusButton.addActionListener(e -> endFocusMode());
    }

    private void startFocusMode() {
        remainingSeconds = 5 * 60;
        overlayPanel.setVisible(true);
        startFocusButton.setEnabled(false);
        stopFocusButton.setEnabled(true);
        focusTimer.start();
    }

    private void endFocusMode() {
        focusTimer.stop();
        overlayPanel.setVisible(false);
        startFocusButton.setEnabled(true);
        stopFocusButton.setEnabled(false);
    }
}

