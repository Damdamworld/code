package com.pupku.detoxtracker.view;

import javax.swing.*;
import java.awt.*;

/**
 * Panel for displaying user achievements and badges.
 */
public class RewardPanel extends JPanel {
    public RewardPanel() {
        setLayout(new BorderLayout(10, 10));
        JLabel title = new JLabel("Achievements & Badges", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        String[] badges = {
            "First Timer - Completed first session",
            "5-Min Focus - Used Focus Mode",
            "10 Challenges - Completed 10 daily challenges",
            "Consistency - Used app for 7 consecutive days",
            "Night Owl - No usage after 8 PM"
        };

        JPanel badgeContainer = new JPanel(new GridLayout(0, 2, 10, 10));
        badgeContainer.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        for (String desc : badges) {
            JPanel badgePanel = new JPanel(new BorderLayout());
            badgePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            JLabel icon = new JLabel("🏅", SwingConstants.CENTER);
            icon.setFont(new Font("SansSerif", Font.PLAIN, 32));
            badgePanel.add(icon, BorderLayout.WEST);
            JLabel label = new JLabel(desc);
            label.setFont(new Font("SansSerif", Font.PLAIN, 16));
            badgePanel.add(label, BorderLayout.CENTER);
            badgeContainer.add(badgePanel);
        }
        add(new JScrollPane(badgeContainer), BorderLayout.CENTER);
}
}
