package com.pupku.detoxtracker.service;

/**
 * DTO for persisting total recorded usage seconds.
 */
public class TimerData {
    private long totalSeconds;

    // Jackson requires a no‐arg constructor
    public TimerData() {
        this.totalSeconds = 0;
    }

    // Convenience constructor
    public TimerData(long totalSeconds) {
        this.totalSeconds = totalSeconds;
    }

    public long getTotalSeconds() {
        return totalSeconds;
    }

    public void setTotalSeconds(long totalSeconds) {
        this.totalSeconds = totalSeconds;
    }
}
