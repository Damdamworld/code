package com.pupku.detoxtracker.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;

/**
 * Reads and writes JSON data to a file in the user's home directory.
 */
public class PersistenceHelper {
    private final ObjectMapper mapper = new ObjectMapper();
    private final File file;

    public PersistenceHelper(String filename) {
        this.file = new File(System.getProperty("user.home"), filename);
    }

    /**
     * Loads an object of the given type from JSON; returns a new instance on error.
     */
    public <T> T load(Class<T> clazz) {
        try {
            if (!file.exists()) {
                file.createNewFile();
                return clazz.getDeclaredConstructor().newInstance();
            }
            return mapper.readValue(file, clazz);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                return clazz.getDeclaredConstructor().newInstance();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    /**
     * Saves the given object to JSON in the file.
     */
    public void save(Object data) {
        try {
            mapper.writerWithDefaultPrettyPrinter().writeValue(file, data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
