package com.pupku.detoxtracker.service;

import java.time.Duration;
import java.time.Instant;

/**
 * Manages timing sessions and tracks total usage duration.
 */
public class TimerManager {
    private Instant sessionStart;
    private Duration totalDuration;

    public TimerManager() {
        this.totalDuration = Duration.ZERO;
    }

    public TimerManager(long initialSeconds) {
        this.totalDuration = Duration.ofSeconds(initialSeconds);
    }

    public void startSession() {
        if (sessionStart == null) {
            sessionStart = Instant.now();
        }
    }

    public Duration stopSession() {
        if (sessionStart == null) {
            return Duration.ZERO;
        }
        Duration elapsed = Duration.between(sessionStart, Instant.now());
        totalDuration = totalDuration.plus(elapsed);
        sessionStart = null;
        return elapsed;
    }

    public Duration getTotalDuration() {
        return totalDuration;
    }

    public void reset() {
        sessionStart = null;
        totalDuration = Duration.ZERO;
    }
}

