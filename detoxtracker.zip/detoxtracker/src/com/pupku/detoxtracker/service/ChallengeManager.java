package com.pupku.detoxtracker.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Tracks completed challenges and provides history.
 */
public class ChallengeManager {
    private final List<String> completedChallenges;

    public ChallengeManager() {
        this.completedChallenges = new ArrayList<>();
    }

    public ChallengeManager(List<String> initialChallenges) {
        this.completedChallenges = new ArrayList<>(initialChallenges);
    }

    public void completeChallenge(String challenge) {
        if (challenge != null && !challenge.isBlank()) {
            completedChallenges.add(challenge);
        }
    }

    public List<String> getChallengeHistory() {
        return Collections.unmodifiableList(completedChallenges);
    }

    public void resetHistory() {
        completedChallenges.clear();
    }
}

