package com.pupku.detoxtracker.service;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO for persisting history of completed challenges.
 */
public class ChallengeData {
    private List<String> completed = new ArrayList<>();

    // Jackson requires a no‐arg constructor
    public ChallengeData() {}

    // Convenience constructor
    public ChallengeData(List<String> completed) {
        this.completed = new ArrayList<>(completed);
    }

    public List<String> getCompleted() {
        return completed;
    }

    public void setCompleted(List<String> completed) {
        this.completed = completed;
    }
}
